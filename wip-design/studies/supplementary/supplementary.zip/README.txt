Iterative Prompting: Programmatic Data Exploration for Non-programmers
----------------------------------------------------------------------

### Supplementary materials ###

 * source - contains a snapshot of the source code of The Gamma 
   based on the public open-source version (this is not executable 
   without some configuration, e.g. to connect to a database)
 * study - contains detailed information about tasks done in the user study
 * questionnaire - contains questionnaire that was given to participants
   at the end of the study (the results are not reported in the paper)